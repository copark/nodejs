var page = 2;

$(function(){
	// 오늘 날짜 세팅
	$("#time > time").attr("datetime", Util.dateToString("-")).text(Util.dateToString("."));
	
	// 쿠폰 상세보기 클릭 이벤트	
	
	// 이전/다음 페이지 클릭 이벤트	
	
	// 쿠폰 목록을 조회한다.
	
});

// 쿠폰 상세정보를 보여준다.
function couponDetail(coupon){
	// 상세보기의 탭 이벤트를 추가한다.
	
	// 쿠폰 상세정보를 보여준다.
	
}

// 쿠폰 상세보기를 닫는다.
function couponPreview(coupon){	
	// 쿠폰 상세보기를 닫는다.
	
	// 갤러리 탭으로 초기화한다.
	
}

// 쿠폰 상세보기 이벤트와 상세보기 닫기 이벤트를 추가한다.
function setDetailEvent(){
	// 쿠폰 상세보기 이벤트(이미지 클릭)
	
	// 상세보기 닫기 이벤트
	
}

// 페이지를 이동한다.
function movePage(page){
	var firstAct = (page-1) * 5;	// 현재 페이지 첫 쿠폰 번호
	var lastAct = (page*5) - 1;		// 현재 페이지 마지막 쿠폰 번호
	
}

// 이전/다음 버튼 이벤트 등록
function setSlideEvent(){
	// 이전 버튼을 클릭할 경우
	
	// 다음 버튼을 클릭할 경우
	
};

// 상세보기의 지정한 탭을 보여준다.
function tabView(tab){
	
};

// 쿠폰 목록을 조회한다.
function getCouponList(){
	
}








































// 구매하기 버튼 클릭 이벤트 등록
function setBuyFormEvent(){
	
}

// 구매화면을 보여준다.
function showBuyForm(coupon){	
	coupon.children(".coupon_tab").hide().next().show();
}

// 구매화면을 숨긴다.
function hideBuyForm(coupon){
	coupon.children(".coupon_tab").show().next().hide();
}

// 구매수량을 수정했을 때 결제가격을 다시 계산한다.
function setPrice(element, price){
	$(element).parents(".buy_section").find("output").text($(element).val() * price);
}

// 구매하기
function setBuyEvent(coupon){
	
}









